import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: { ignoreBuildErrors: true },
  output: "standalone",
  images: {
    unoptimized: true,
    localPatterns: [{ pathname: "/horsecoder-storage/**" }],
  },
  async redirects() {
    return [{ source: "/index/main", destination: "/rsi", permanent: false }];
  },
  async rewrites() {
    if (process.env.NODE_ENV !== "development") return [];
    const targets = [
      ["/mall-dialogue", process.env.RSI_DIALOGUE_UPSTREAM],
      ["/app-im", process.env.RSI_IM_UPSTREAM],
      ["/horsecoder-storage", process.env.RSI_STORAGE_UPSTREAM],
    ];
    return targets.flatMap(([prefix, target]) => target
      ? [{ source: `${prefix}/:path*`, destination: `${target.replace(/\/$/, "")}/:path*` }]
      : []);
  },
};

export default nextConfig;
