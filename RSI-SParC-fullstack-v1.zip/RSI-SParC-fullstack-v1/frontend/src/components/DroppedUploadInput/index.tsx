import React from 'react';
import { Input, Button } from 'antd';
import styles from './index.module.css';
type Props={value?:string;onChangeValue?:(v:string)=>void;onSubmitQuery?:()=>void;disabled?:boolean;loading?:boolean;placeholder?:string;[key:string]:unknown};
export default function DroppedUploadInputComponent(props:Props){return <div className={styles.div+' rsi-native-input'}><Input.TextArea aria-label="RSI查询输入框" value={props.value} onChange={e=>props.onChangeValue?.(e.target.value)} placeholder={props.placeholder} disabled={props.disabled} autoSize={{minRows:3,maxRows:7}} onPressEnter={e=>{if(!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();if(!props.disabled&&props.value?.trim())props.onSubmitQuery?.();}}}/><Button type="primary" loading={props.loading} disabled={props.disabled||!props.value?.trim()} onClick={props.onSubmitQuery}>发送</Button></div>;}
