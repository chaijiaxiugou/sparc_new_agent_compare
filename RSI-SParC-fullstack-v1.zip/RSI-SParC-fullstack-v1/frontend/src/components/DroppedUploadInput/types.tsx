

export type DroppedUploadInputWrapperProps =  {
  value: string | undefined;
  placeholder: string | undefined;
  disabled: boolean;
  readOnly: boolean;
  loading: boolean;
  autoSize: boolean | { minRows?: number; maxRows?: number };
  accept: string | string[] | undefined;
  maxCount: number | undefined;
  maxSize: number | undefined;
  onInputChange: (value: string) => void;
  onSubmit: (value: string, attachments: AttachmentsItemType[]) => void;
  onCancel: () => void;
  onAttachmentsChange: (items: AttachmentsItemType[]) => void;;
};

export type DroppedUploadInputProps = {
  value: string | undefined;
  placeholder: string | undefined;
  disabled: boolean;
  readOnly: boolean;
  loading: boolean;
  autoSize: boolean | { minRows?: number; maxRows?: number };
  accept: string | string[] | undefined;
  maxCount: number | undefined;
  maxSize: number | undefined;
  onInputChange: (value: string) => void;
  onSubmit: (value: string, attachments: AttachmentsItemType[]) => void;
  onCancel: () => void;
  onAttachmentsChange: (items: AttachmentsItemType[]) => void;;
};

