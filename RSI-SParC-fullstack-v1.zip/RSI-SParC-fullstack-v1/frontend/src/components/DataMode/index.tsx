import React from 'react';
import styles from './index.module.css';
import type { DataModeProps } from './types';

/**
 * 组件布局: 数据模型
 */
const DataModeComponent: React.FC<DataModeProps> = () => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default DataModeComponent;
