

export type DataModeWrapperProps =  {
};

export type DataModeProps = {
};

