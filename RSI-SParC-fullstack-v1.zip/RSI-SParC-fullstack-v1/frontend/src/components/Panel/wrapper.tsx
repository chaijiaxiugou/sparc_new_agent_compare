'use client';
export { OriginalPanelBridge as default } from '@/src/experimental/Bridge';
