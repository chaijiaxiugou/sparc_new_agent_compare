import React from 'react';
import styles from './index.module.css';
import type { PanelProps as OriginalPanelProps } from './types';

type PanelProps = OriginalPanelProps & { experimentMenu?: React.ReactNode; experimentContent?: React.ReactNode };

/**
 * 组件布局: 面板
 */
const PanelComponent: React.FC<PanelProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      >
        <div
          className={styles.panelContainer}
        >
          <div
            className={styles.panelContainerDiv0}
          >
            {props.experimentMenu}
          </div>
          <div
            className={styles.panelContainerDiv1}
          >
            
            
            <div className="rsi-original-panel-content">{props.experimentContent}</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PanelComponent;
