

export type FilePreviewComponentWrapperProps =  {
  documents: string[] | undefined;
};

export type FilePreviewComponentProps = {
  documents: string[] | undefined;
};

