import React from 'react';
import styles from './index.module.css';
import type { FilePreviewComponentProps } from './types';

/**
 * 组件布局: 文件预览组件
 */
const FilePreviewComponentComponent: React.FC<FilePreviewComponentProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default FilePreviewComponentComponent;
