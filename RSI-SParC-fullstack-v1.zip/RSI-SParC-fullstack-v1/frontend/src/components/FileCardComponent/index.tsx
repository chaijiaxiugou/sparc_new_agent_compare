import React from 'react';
import styles from './index.module.css';
import type { FileCardComponentProps } from './types';

/**
 * 组件布局: 文件卡片组件
 */
const FileCardComponentComponent: React.FC<FileCardComponentProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default FileCardComponentComponent;
