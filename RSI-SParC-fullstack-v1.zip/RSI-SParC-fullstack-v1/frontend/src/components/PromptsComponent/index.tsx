import React from 'react';
import styles from './index.module.css';
import type { PromptsComponentProps } from './types';

/**
 * 组件布局: 提示集组件
 */
const PromptsComponentComponent: React.FC<PromptsComponentProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default PromptsComponentComponent;
