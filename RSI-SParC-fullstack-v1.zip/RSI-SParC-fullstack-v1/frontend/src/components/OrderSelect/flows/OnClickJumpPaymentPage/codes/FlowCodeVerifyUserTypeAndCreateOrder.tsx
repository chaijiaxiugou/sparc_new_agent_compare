import type { OrderDetails } from '@/flows/com.horsecoder.pay/CreatePaymentOrder/types/OrderDetails';

/**
 * 入参明细:
 * setter 页面设置器
 * dispatch WEB状态更新
 * loggedinUser 登录用户
 * memberType 会员类型
 */
export interface FlowCodeVerifyUserTypeAndCreateOrderParams {
  setter: any;
  dispatch: any;
  loggedinUser: any;
  memberType: any;
}

/**
 * 出参明细:
 * paymentOrder 支付订单实体
 * orderDetails 订单明细
 */
export interface FlowCodeVerifyUserTypeAndCreateOrderResults {
  paymentOrder: any;
  orderDetails?: OrderDetails[];
}

/**
 * 验证用户类型并创建订单
 * FLOW_NODE_VERIFY_USER_TYPE_AND_CREATE_ORDER
 * 唯一id: OrderSelect/FLOW_CODE_VERIFY_USER_TYPE_AND_CREATE_ORDER
 */
export const flowCodeVerifyUserTypeAndCreateOrder = async (params: FlowCodeVerifyUserTypeAndCreateOrderParams): Promise<FlowCodeVerifyUserTypeAndCreateOrderResults> => {
  // 初始化流程出参
  let paymentOrder;
  let orderDetails;
  // 开始流程
  const { setter } = params;
  const { dispatch } = params;
  const { loggedinUser } = params;
  const { memberType } = params;
  // 结束流程
  return {
    paymentOrder,
    orderDetails,
  }
};
