
/**
 * 入参明细:
 * paymentOrderNumber 支付订单号
 * loggedinUser 登录用户
 */
export interface FlowCodeJumpPaymentPageParams {
  paymentOrderNumber: string;
  loggedinUser: any;
}

/**
 * 出参明细:
 */
export interface FlowCodeJumpPaymentPageResults {
}

/**
 * 跳转到支付页
 * FLOW_NODE_JUMP_PAYMENT_PAGE
 * 唯一id: OrderSelect/FLOW_CODE_JUMP_PAYMENT_PAGE
 */
export const flowCodeJumpPaymentPage = async (params: FlowCodeJumpPaymentPageParams): Promise<FlowCodeJumpPaymentPageResults> => {
  // 初始化流程出参
  // 开始流程
  const { paymentOrderNumber } = params;
  const { loggedinUser } = params;
  // 结束流程
  return {}
};
