import type { OrderDetails } from '@/flows/com.horsecoder.pay/CreatePaymentOrder/types/OrderDetails';

/**
 * 入参明细:
 * setter 页面设置器
 * dispatch WEB状态更新
 * loggedinUser 登录用户
 * memberType 会员类型
 */
export interface FlowCodeFrontEndCreatesPaymentOrdersParams {
  setter: any;
  dispatch: any;
  loggedinUser: any;
  memberType: any;
}

/**
 * 出参明细:
 * paymentOrder 支付订单实体
 * orderDetails 订单明细
 */
export interface FlowCodeFrontEndCreatesPaymentOrdersResults {
  paymentOrder: any;
  orderDetails?: OrderDetails[];
}

/**
 * 前端创建支付订单
 * FLOW_NODE_FRONT_END_CREATES_PAYMENT_ORDERS
 * 唯一id: OrderSelect/FLOW_CODE_FRONT_END_CREATES_PAYMENT_ORDERS
 */
export const flowCodeFrontEndCreatesPaymentOrders = async (params: FlowCodeFrontEndCreatesPaymentOrdersParams): Promise<FlowCodeFrontEndCreatesPaymentOrdersResults> => {
  // 初始化流程出参
  let paymentOrder;
  let orderDetails;
  // 开始流程
  const { setter } = params;
  const { dispatch } = params;
  const { loggedinUser } = params;
  const { memberType } = params;
  // 结束流程
  return {
    paymentOrder,
    orderDetails,
  }
};
