
/**
 * 入参明细:
 * setter 页面设置器
 * dispatch WEB状态更新
 * loggedinUser 登录用户
 * paymentOrderNumber 支付订单号
 */
export interface FlowCodeOnClickCancelOrderParams {
  setter: any;
  dispatch: any;
  loggedinUser: any;
  paymentOrderNumber: any;
}

/**
 * 出参明细:
 * paymentOrderNumber 支付订单号
 * accountId 账户ID
 */
export interface FlowCodeOnClickCancelOrderResults {
  paymentOrderNumber: string;
  accountId: string;
}

/**
 * 点击取消订单
 * FLOW_NODE_ON_CLICK_CANCEL_ORDER
 * 唯一id: OrderSelect/FLOW_CODE_ON_CLICK_CANCEL_ORDER
 */
export const flowCodeOnClickCancelOrder = async (params: FlowCodeOnClickCancelOrderParams): Promise<FlowCodeOnClickCancelOrderResults> => {
  // 初始化流程出参
  let paymentOrderNumber;
  let accountId;
  // 开始流程
  const { setter } = params;
  const { dispatch } = params;
  const { loggedinUser } = params;
  const { paymentOrderNumber } = params;
  // 结束流程
  return {
    paymentOrderNumber,
    accountId,
  }
};
