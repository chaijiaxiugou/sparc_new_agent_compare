import type { UserConversationDetail } from '@/flows/com.horsecoder.im/QueryUserConversationListBasedOnUserIdList/types/UserConversationDetail';

/**
 * 入参明细:
 * userConversationDetail 用户对话详情
 * conversationId 对话ID
 * setter 页面设置器
 */
export interface FlowNodeConvertDialogueCardListParams {
  userConversationDetail: UserConversationDetail[];
  conversationId: any;
  setter: any;
}

/**
 * 出参明细:
 * dialogueCardList 对话卡片列表
 */
export interface FlowNodeConvertDialogueCardListResults {
  dialogueCardList: any;
}

/**
 * 转化对话卡片列表
 * FLOW_NODE_CONVERT_DIALOGUE_CARD_LIST
 * 唯一id: LeftComponent/FLOW_NODE_CONVERT_DIALOGUE_CARD_LIST
 */
export const flowNodeConvertDialogueCardList = async (params: FlowNodeConvertDialogueCardListParams): Promise<FlowNodeConvertDialogueCardListResults> => {
  // 初始化流程出参
  let dialogueCardList;
  // 开始流程
  const { userConversationDetail } = params;
  const { conversationId } = params;
  const { setter } = params;
  // 结束流程
  return {
    dialogueCardList,
  }
};
