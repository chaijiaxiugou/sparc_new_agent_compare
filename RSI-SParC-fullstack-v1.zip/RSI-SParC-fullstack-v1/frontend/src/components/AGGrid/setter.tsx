

export type Setter = {
};