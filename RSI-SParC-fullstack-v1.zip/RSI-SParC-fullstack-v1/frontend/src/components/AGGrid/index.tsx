import React from 'react';
import styles from './index.module.css';
import type { AGGridProps } from './types';

/**
 * 组件布局: AGGrid数据展示
 */
const AGGridComponent: React.FC<AGGridProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default AGGridComponent;
