import React from 'react';
import styles from './index.module.css';
import type { ModelCanvasProps } from './types';

/**
 * 组件布局: 模型画布
 */
const ModelCanvasComponent: React.FC<ModelCanvasProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
        {...props.actions.eventsDiv}
        canvasConfig={props.canvasConfig}
        id="model-ModelCanvasCardsix"
      />
    </>
  );
};

export default ModelCanvasComponent;
