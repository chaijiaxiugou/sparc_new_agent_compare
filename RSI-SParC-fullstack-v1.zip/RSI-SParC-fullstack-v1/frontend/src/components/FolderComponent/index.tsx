import React from 'react';
import styles from './index.module.css';
import type { FolderComponentProps } from './types';

/**
 * 组件布局: 文件夹组件
 */
const FolderComponentComponent: React.FC<FolderComponentProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default FolderComponentComponent;
