import React from 'react';
import Image from 'next/image';
import styles from './index.module.css';
import type { GroupChatSettingAvatarProps } from './types';

/**
 * 组件布局: 群聊设置头像
 */
const GroupChatSettingAvatarComponent: React.FC<GroupChatSettingAvatarProps> = () => {

  return (
    <>
      <div
        className={styles.div}
      >
        <Image
          className={styles.divImage0}
          src="https://beta.horsecoder.com/remote-storage/api/sys/storage/file/preview?fileName=MkE3QzdDQkMxRkExQTc4NjU0MTlFMkM5NTRGNUYxMkUucG5n&user=prod"
          alt=""
          width="40"
          height="40"
        />
        <p
          className={styles.divP1}
        >
          {`正文段落222`}
        </p>
      </div>
    </>
  );
};

export default GroupChatSettingAvatarComponent;
