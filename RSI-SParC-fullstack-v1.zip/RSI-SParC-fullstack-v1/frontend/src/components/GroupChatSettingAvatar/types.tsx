

export type GroupChatSettingAvatarWrapperProps =  {
};

export type GroupChatSettingAvatarProps = {
};

