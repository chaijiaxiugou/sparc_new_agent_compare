

export type CollaborativeFlowWrapperProps =  {
  agents: any[] | undefined;
  scenarios: any[] | undefined;
  scenarioIdx: number;
  stepIdx: number;
  playing: string | undefined;
  activeAgentKeys: string | undefined;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  onSelectScenario: () => void;
  onSelectStep: () => void;
  onPlay: () => void;
  onrReset: () => void;
};

export type CollaborativeFlowProps = {
  agents: any[] | undefined;
  scenarios: any[] | undefined;
  scenarioIdx: number;
  stepIdx: number;
  playing: string | undefined;
  activeAgentKeys: string | undefined;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  onSelectScenario: () => void;
  onSelectStep: () => void;
  onPlay: () => void;
  onrReset: () => void;
};

