'use client';
import React from 'react';
import type { CollaborativeFlowWrapperProps } from './types';
import CollaborativeFlowComponent from './index';


/**
 * 组件逻辑: 协作流程
 */
const CollaborativeFlowWrapper: React.FC<CollaborativeFlowWrapperProps> = (props) => {
  /*
   * 前置代码数据区域
   * 自定义代码区域
   * [YOUR CODE HERE]
   */


  /*
   * [END OF YOUR CODE]
   */
  /*
   * 参考代码生成区域
   * 可以删除或者注释
   * 不可编辑后直接使用
   */
  // 内部数据: 智能体列表(agents)
  const { agents } = props;
  // 内部数据: 场景(scenarios)
  const { scenarios } = props;
  // 内部数据: 场景ID(scenarioIdx)
  const { scenarioIdx } = props;
  // 内部数据: 步骤ID(stepIdx)
  const { stepIdx } = props;
  // 内部数据: playing(playing)
  const { playing } = props;
  // 内部数据: activeAgentKeys(activeAgentKeys)
  const { activeAgentKeys } = props;
  // 内部数据: canvasRef(canvasRef)
  const { canvasRef } = props;
  // 内部数据: 选择场景(onSelectScenario)
  const { onSelectScenario } = props;
  // 内部数据: 选择步骤(onSelectStep)
  const { onSelectStep } = props;
  // 内部数据: 播放(onPlay)
  const { onPlay } = props;
  // 内部数据: 重置(onrReset)
  const { onrReset } = props;

  /*
   * end
   */

  /*
   * 获取父组件传值
   * 定义当前组件数据
   * 定义静态变量
   * 获取组件redux数据
   * 获取组件挂载模型数据
   * 获取组件挂载流程数据
   * 装配子组件数据
   * 自定义代码区域
   * [YOUR CODE HERE]
   */


  /*
   * [END OF YOUR CODE]
   */
  return (
    <CollaborativeFlowComponent 
      agents={agents}
      scenarios={scenarios}
      scenarioIdx={scenarioIdx}
      stepIdx={stepIdx}
      playing={playing}
      activeAgentKeys={activeAgentKeys}
      canvasRef={canvasRef}
      onSelectScenario={onSelectScenario}
      onSelectStep={onSelectStep}
      onPlay={onPlay}
      onrReset={onrReset}
    />
  );
};

export default CollaborativeFlowWrapper;
