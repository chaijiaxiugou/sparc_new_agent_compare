import React from 'react';
import styles from './index.module.css';
import type { CollaborativeFlowProps } from './types';

/**
 * 组件布局: 协作流程
 */
const CollaborativeFlowComponent: React.FC<CollaborativeFlowProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      >
        <div
          className={styles.divDiv0}
        >
          <div
            className={styles.divDiv0Div0}
          />
          <div
            className={styles.divDiv0Div1}
          />
        </div>
        <div
          className={styles.divDiv1}
        />
      </div>
    </>
  );
};

export default CollaborativeFlowComponent;
