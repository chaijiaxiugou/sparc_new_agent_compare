import React from 'react';
import styles from './index.module.css';
import type { CodeHighlightingProps } from './types';

/**
 * 组件布局: 代码高亮
 */
const CodeHighlightingComponent: React.FC<CodeHighlightingProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      >
        <div
          className={styles.divDiv0}
        />
      </div>
    </>
  );
};

export default CodeHighlightingComponent;
