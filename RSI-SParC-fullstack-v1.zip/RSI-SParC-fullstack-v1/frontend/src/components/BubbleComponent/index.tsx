import React from 'react';
import styles from './index.module.css';
import type { BubbleComponentProps } from './types';

/**
 * 组件布局: 气泡组件
 */
const BubbleComponentComponent: React.FC<BubbleComponentProps> = (props) => {

  return (
    <>
      <div
        className={styles.div}
      />
    </>
  );
};

export default BubbleComponentComponent;
