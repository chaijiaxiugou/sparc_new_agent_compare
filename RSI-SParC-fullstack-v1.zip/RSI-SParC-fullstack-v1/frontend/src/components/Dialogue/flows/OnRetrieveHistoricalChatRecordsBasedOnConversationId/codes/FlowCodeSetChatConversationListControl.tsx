import type { MessageManagementEntity } from '@/flows/com.horsecoder.im/SearchImChatRecordsBasedOnId/types/MessageManagementEntity';

/**
 * 入参明细:
 * messageManagementEntity 消息管理实体
 * setter 页面设置器
 * dispatch WEB状态更新
 * conversationId 对话ID
 */
export interface FlowCodeSetChatConversationListControlParams {
  messageManagementEntity: MessageManagementEntity[];
  setter: any;
  dispatch: any;
  conversationId: any;
}

/**
 * 出参明细:
 */
export interface FlowCodeSetChatConversationListControlResults {
}

/**
 * 设置聊天对话列表控制
 * FLOW_NODE_SET_CHAT_CONVERSATION_LIST_CONTROL
 * 唯一id: Dialogue/FLOW_CODE_SET_CHAT_CONVERSATION_LIST_CONTROL
 */
export const flowCodeSetChatConversationListControl = async (params: FlowCodeSetChatConversationListControlParams): Promise<FlowCodeSetChatConversationListControlResults> => {
  // 初始化流程出参
  // 开始流程
  const { messageManagementEntity } = params;
  const { setter } = params;
  const { dispatch } = params;
  const { conversationId } = params;
  // 结束流程
  return {}
};
