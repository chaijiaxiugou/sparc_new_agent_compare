
/**
 * 入参明细:
 * nicknameDictionaryMap 昵称字典Map
 * dispatch WEB状态更新
 * senderNicknameDictionary 发送人昵称字典
 */
export interface FlowNodeSetSenderNicknameDictionaryParams {
  nicknameDictionaryMap?: any;
  dispatch: any;
  senderNicknameDictionary: any;
}

/**
 * 出参明细:
 */
export interface FlowNodeSetSenderNicknameDictionaryResults {
}

/**
 * 设置发送人昵称字典
 * FLOW_NODE_SET_SENDER_NICKNAME_DICTIONARY
 * 唯一id: Dialogue/FLOW_NODE_SET_SENDER_NICKNAME_DICTIONARY
 */
export const flowNodeSetSenderNicknameDictionary = async (params: FlowNodeSetSenderNicknameDictionaryParams): Promise<FlowNodeSetSenderNicknameDictionaryResults> => {
  // 初始化流程出参
  // 开始流程
  const { nicknameDictionaryMap } = params;
  const { dispatch } = params;
  const { senderNicknameDictionary } = params;
  // 结束流程
  return {}
};
