
/**
 * 入参明细:
 * setter 页面设置器
 * dispatch WEB状态更新
 * latestNewsRecordEntity 最新消息记录实体
 * senderNicknameDictionary 发送人昵称字典
 * conversationId 对话ID
 */
export interface FlowCodeOnUpdateNewMessageEntityParams {
  setter: any;
  dispatch: any;
  latestNewsRecordEntity: any;
  senderNicknameDictionary: any;
  conversationId: any;
}

/**
 * 出参明细:
 */
export interface FlowCodeOnUpdateNewMessageEntityResults {
}

/**
 * 更新新消息实体
 * FLOW_NODE_ON_UPDATE_NEW_MESSAGE_ENTITY
 * 唯一id: Dialogue/FLOW_CODE_ON_UPDATE_NEW_MESSAGE_ENTITY
 */
export const flowCodeOnUpdateNewMessageEntity = async (params: FlowCodeOnUpdateNewMessageEntityParams): Promise<FlowCodeOnUpdateNewMessageEntityResults> => {
  // 初始化流程出参
  // 开始流程
  const { setter } = params;
  const { dispatch } = params;
  const { latestNewsRecordEntity } = params;
  const { senderNicknameDictionary } = params;
  const { conversationId } = params;
  // 结束流程
  return {}
};
