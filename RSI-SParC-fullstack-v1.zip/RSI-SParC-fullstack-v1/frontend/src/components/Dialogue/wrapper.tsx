'use client';
export { OriginalDialogueBridge as default } from '@/src/experimental/Bridge';
