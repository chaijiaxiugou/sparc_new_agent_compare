import { Suspense } from 'react';
import MainWrapper from '@/src/xpages/Main/wrapper';
export default function RSI(){return <Suspense fallback={null}><MainWrapper/></Suspense>;}
