'use client';
import React, { useEffect, useRef, useState } from 'react';
import './style.css';

type DB = { id: string; tables: number; split: string; schema: string };
type Result = { status: string; prediction: string; model_calls: number; tool_calls: number; seconds: number; trace: Array<{ response?: string; tool?: { action: unknown; observation: unknown } }> };
type Entry = { question: string; state: string; result?: Result; error?: string };
type Job = { run_id: string; state: string; phase?: string; manifest?: { completed_turns?: number; expected_turns?: number }; result?: Record<string, unknown>; log_tail?: string };

async function api(path: string, body?: unknown) {
  const r = await fetch('/api/experiment/' + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body), cache: 'no-store' });
  const data = await r.json(); if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`); return data;
}
const pause = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export default function ExperimentPage() {
  const [health, setHealth] = useState<{ api_config_filled: boolean; api_key_present: boolean }>();
  const [databases, setDatabases] = useState<DB[]>([]); const [database, setDatabase] = useState('flight_2');
  const [mode, setMode] = useState('agent'); const [session, setSession] = useState('');
  const [question, setQuestion] = useState(''); const [entries, setEntries] = useState<Entry[]>([]);
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const [job, setJob] = useState<Job>(); const [jobMode, setJobMode] = useState('backend');
  const [split, setSplit] = useState('train'); const [limit, setLimit] = useState(3);
  const [runId, setRunId] = useState(''); const [goldPolicy, setGoldPolicy] = useState('raw');
  const alive = useRef(true); const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const configured = Boolean(health?.api_config_filled && health?.api_key_present);
  const selected = databases.find(d => d.id === database);

  async function refresh() {
    try { const [h, db] = await Promise.all([api('health'), api('databases')]); if (alive.current) { setHealth(h); setDatabases(db); setError(''); } }
    catch (e) { if (alive.current) setError((e as Error).message); }
  }
  useEffect(() => { alive.current = true; refresh(); return () => { alive.current = false; if (timer.current) clearInterval(timer.current); }; }, []);
  useEffect(() => {
    if (!job || !['queued', 'running'].includes(job.state)) return;
    let polling = false;
    timer.current = setInterval(async () => { if (polling) return; polling = true; try { const j = await api('experiments/' + job.run_id); if (alive.current) setJob(j); } catch (e) { if (alive.current) setError((e as Error).message); } finally { polling = false; } }, 2000);
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [job?.run_id, job?.state]);

  async function send() {
    if (!question.trim() || busy || !configured) return;
    const text = question.trim(); setBusy(true); setError('');
    const index = entries.length; setEntries(prev => [...prev, { question: text, state: '提交中' }]); setQuestion('');
    const update = (value: Partial<Entry>) => setEntries(prev => prev.map((r, i) => i === index ? { ...r, ...value } : r));
    try {
      let sid = session;
      if (!sid) { const s = await api('sessions', { database_id: database, experiment_id: 'rsi_frontend_' + Date.now(), mode }); sid = s.session_id; setSession(sid); }
      const task = await api(`sessions/${sid}/query`, { question: text });
      const start = Date.now(); let done = false;
      while (alive.current && Date.now() - start < 600000) {
        const t = await api('tasks/' + task.task_id); update({ state: t.state });
        if (t.state === 'failed') throw new Error(t.error || '任务失败');
        if (t.state === 'completed') { update({ state: t.result.status === 'final' ? '已完成' : '未生成有效最终答案', result: t.result }); done = true; break; }
        await pause(700);
      }
      if (!done && alive.current) throw new Error('页面等待超时，后端任务可能仍在运行，请查看日志。');
    } catch (e) { update({ state: '失败', error: (e as Error).message }); setError((e as Error).message); }
    finally { if (alive.current) setBusy(false); }
  }
  async function startBatch() {
    const id = runId || `${split}_${jobMode}_${Date.now()}`; setError('');
    if (limit === 0 && !window.confirm('将运行完整划分并调用真实模型 API，可能产生费用。确认开始？')) return;
    try { setJob(await api('experiments', { run_id: id, mode: jobMode, split, limit, confirm_full: limit === 0 })); setRunId(id); }
    catch (e) { setError((e as Error).message); }
  }
  async function evaluate() { if (!job) return; try { setJob(await api(`experiments/${job.run_id}/evaluate`, { gold_policy: goldPolicy })); setError(''); } catch (e) { setError((e as Error).message); } }
  function download() { const blob = new Blob([JSON.stringify({ database, mode, session, entries }, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'rsi-experiment-dialogue.json'; a.click(); URL.revokeObjectURL(url); }

  return <main className="experiment">
    <header><div><small>RSI · SPARC EXPERIMENT</small><h1>数据查询实验台</h1><p>RSI 前端连接自建 Agent 后端 · 真实模型 API · 官方评估</p></div><button onClick={refresh}>刷新连接</button></header>
    <div className={'banner ' + (configured ? 'ready' : '')}>{health ? configured ? '后端已连接 · 模型配置已填写（首次调用后确认可用性）' : '后端已连接 · 等待填写模型 API 地址、模型 ID 和密钥' : '正在连接实验后端…'}</div>
    {error && <div role="alert" className="error">{error}</div>}
    <div className="workspace">
      <aside>
        <h2>查询设置</h2><label>原始 SParC 数据库<select aria-label="数据库" disabled={busy || Boolean(session)} value={database} onChange={e => setDatabase(e.target.value)}>{databases.map(d => <option key={d.id} value={d.id}>{d.id} · {d.split}</option>)}</select></label>
        <label>运行方式<select aria-label="运行方式" disabled={busy || Boolean(session)} value={mode} onChange={e => setMode(e.target.value)}><option value="agent">Agent · 可执行与修正 SQL</option><option value="baseline">基线 · 一次生成 SQL</option></select></label>
        <button disabled={busy} onClick={() => { setSession(''); setEntries([]); setError(''); }}>新建独立对话</button>
        <p className="muted">同一对话保留此前问题与预测。切换数据库或方式前，请新建对话。</p>
        <details><summary>数据库结构 · {selected?.tables || 0} 张表</summary><pre>{selected?.schema || '等待加载'}</pre></details>
        <p className="muted">{session ? '会话 ' + session.slice(0, 8) : '发送首条问题时创建会话'}</p>
      </aside>
      <section className="conversation"><div className="section-title"><h2>连续查询</h2><button disabled={!entries.length} onClick={download}>导出记录</button></div>
        {!entries.length && <div className="empty"><h3>从一个数据库问题开始</h3><p>选择数据库后，可以连续追问。最终 SQL 和工具反馈会显示在这里。</p><button onClick={() => setQuestion('What are all the airlines?')}>填入 flight_2 示例问题</button></div>}
        {entries.map((entry, i) => <article key={i}><h3>{i + 1}. {entry.question}</h3><span className="muted">{entry.state}</span>{entry.error && <p className="error">{entry.error}</p>}{entry.result && <><pre className="sql">{entry.result.prediction}</pre><p className="muted">模型调用 {entry.result.model_calls} 次 · 工具调用 {entry.result.tool_calls} 次 · {entry.result.seconds.toFixed(1)} 秒</p><details><summary>查看实际模型与工具轨迹</summary>{entry.result.trace.map((t, k) => <div key={k}><pre>{t.response}</pre>{t.tool && <pre>{JSON.stringify(t.tool, null, 2)}</pre>}</div>)}</details></>}</article>)}
        <form onSubmit={e => { e.preventDefault(); send(); }}><textarea aria-label="查询问题" placeholder={configured ? '输入问题或继续追问…' : '请先在本机配置模型 API，密钥不在网页填写'} value={question} onChange={e => setQuestion(e.target.value)} disabled={busy} /><button className="primary" disabled={!configured || busy || !question.trim()} type="submit">{busy ? 'Agent 运行中…' : '发送查询'}</button></form>
      </section>
    </div>
    <section className="batch"><h2>批量实验与官方评价</h2><p className="muted">独立于上面的手动对话。每组样本自动创建新会话，标准答案仅用于事后评价。</p>
      <div className="batch-options"><label>方法<select value={jobMode} onChange={e => setJobMode(e.target.value)}><option value="backend">自建后端 Agent</option><option value="baseline">直接模型基线</option></select></label><label>划分<select value={split} onChange={e => setSplit(e.target.value)}><option value="train">train · 联调</option><option value="dev">dev · 官方评价</option></select></label><label>对话数（0=全部）<input type="number" min={0} max={422} value={limit} onChange={e => setLimit(Number(e.target.value))} /></label><label>Run ID<input placeholder="留空自动生成" value={runId} onChange={e => setRunId(e.target.value)} /></label></div>
      <button className="primary" onClick={startBatch} disabled={!configured || ['queued', 'running'].includes(job?.state || '')}>开始真实 API 实验</button>
      {job && <div className="job"><h3>{job.run_id}</h3><p>{job.phase} · {job.state} {job.manifest?.completed_turns !== undefined && `· ${job.manifest.completed_turns}/${job.manifest.expected_turns} 轮`}</p><label>Gold 政策<select value={goldPolicy} onChange={e => setGoldPolicy(e.target.value)}><option value="raw">原始标准答案（完整 dev 有一条已知别名问题）</option><option value="alias_fix">显式修正一条别名问题，报告中注明</option></select></label><button onClick={evaluate} disabled={job.state !== 'completed'}>运行官方评估（仅 dev）</button>{job.result && <pre>{JSON.stringify(job.result, null, 2)}</pre>}<details><summary>运行日志</summary><pre>{job.log_tail || '等待日志'}</pre></details></div>}
    </section>
    <footer>这是 RSI 前端与自建实验后端的集成，不代表原版 RSI Agent。未调用模型时不生成成绩；训练集联调不用于报告开发集成绩。</footer>
  </main>;
}
