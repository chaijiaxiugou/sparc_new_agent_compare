import { readFile } from 'node:fs/promises';
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

async function proxy(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const { path } = await context.params;
  const route = path.join('/');
  const allowed = request.method === 'GET'
    ? /^(health|databases|tasks\/[a-zA-Z0-9_-]+|experiments\/[a-zA-Z0-9_-]+)$/.test(route)
    : /^(sessions|sessions\/[a-zA-Z0-9_-]+\/query|experiments|experiments\/[a-zA-Z0-9_-]+\/evaluate)$/.test(route);
  if (!allowed) return NextResponse.json({ error: 'Unsupported experiment endpoint' }, { status: 404 });
  const origin = request.headers.get('origin');
  if (request.method !== 'GET' && origin) {
    let sameOrigin = false;
    try { const parsed = new URL(origin); sameOrigin = ['http:', 'https:'].includes(parsed.protocol) && parsed.host === request.headers.get('host'); } catch { /* reject malformed Origin */ }
    if (!sameOrigin) return NextResponse.json({ error: 'Cross-origin submission refused' }, { status: 403 });
  }
  try {
    const tokenFile = process.env.SPARC_BACKEND_TOKEN_FILE;
    if (!tokenFile) return NextResponse.json({ error: 'Frontend server missing SPARC_BACKEND_TOKEN_FILE' }, { status: 503 });
    const token = (await readFile(tokenFile, 'utf8')).trim();
    const body = request.method === 'POST' ? await request.text() : undefined;
    if (body && body.length > 1048576) return NextResponse.json({ error: 'Request too large' }, { status: 413 });
    const response = await fetch(`${process.env.SPARC_BACKEND_URL || 'http://127.0.0.1:8765'}/${route}`, {
      method: request.method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body, cache: 'no-store', signal: AbortSignal.timeout(35000),
    });
    return new NextResponse(await response.text(), { status: response.status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ error: '实验后端不可达，请启动本机 8765 服务并检查服务器端配置。' }, { status: 503 });
  }
}
export const GET = proxy;
export const POST = proxy;
