import { ReduxProvider } from '@/src/store/Provider';
import HorsecoderPermissionLayoutWrapper from '@/src/layouts/HorsecoderPermissionLayout/wrapper';
export default function LegacyLayout({ children }: { children: React.ReactNode }) {
  return <ReduxProvider><HorsecoderPermissionLayoutWrapper>{children}</HorsecoderPermissionLayoutWrapper></ReduxProvider>;
}
