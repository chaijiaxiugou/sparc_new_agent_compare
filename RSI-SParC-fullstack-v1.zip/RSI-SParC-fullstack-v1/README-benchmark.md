# SParC Agent Benchmark

用同一 Qwen API 比较多轮 Text-to-SQL 的直接生成基线、单 Agent 和双 Agent。单 Agent 可以查看数据库结构、试跑只读 SQL 并根据执行结果调整查询。双 Agent 将候选 SQL 交给独立的核查 Agent，生成 Agent 可根据意见修订一次。两种 Agent 共享每轮 5 次模型调用上限。双 Agent 预留两次用于核查和可选修订。

## 单 Agent 和双 Agent

两组均独立跑完 SParC Dev 的 422 段对话和 1,203 轮，使用同一模型、数据和每轮总调用上限。

| 方法 | 单轮 EM | 整段 EM | 单轮 Test Suite | 整段 Test Suite | 已记录 Token |
|---|---:|---:|---:|---:|---:|
| 单 Agent | 52.5% | 31.5% | 63.3% | 41.5% | 1,100,157 |
| 双 Agent | 50.3% | 29.4% | 60.7% | 37.9% | 1,618,796 |

本次双 Agent 的四项得分均下降。独立核查促成了 99 轮修订，另有 32 轮耗尽候选生成预算。由于两组候选生成的可用次数不同，这次实验比较的是同一总预算下的两套流程。双 Agent 推理中途短暂断连后从缓存继续。Windows 执行评分进程曾崩溃，两组均使用已保存的预测按同一口径复评。[实验对照表](results/single-dual.md) · [CSV](results/single-dual.csv) · [核验数据](results/single-dual.json)

## 早期基线与工具 Agent 实验

| 方法 | 划分 | 单轮 EM | 整段 EM | 单轮 Test Suite | 整段 Test Suite |
|---|---|---:|---:|---:|---:|
| Qwen-plus 模型基线 | Dev | 55.1% | 35.8% | 63.8% | 43.1% |
| Qwen-plus 工具 Agent | Dev | 51.4% | 31.3% | 61.9% | 41.2% |
| Qwen-plus 工具 Agent | Train | 53.1% | 28.9% | 未评估 | 未评估 |

Dev 两组各 422 段对话、1,203 轮。Train 实验覆盖 3,030 段非空对话、9,025 轮。Dev 上 Agent 的已记录 Token 用量是基线的 2.54 倍，四项准确率均较低。汇总与复核记录见 [results/summary.csv](results/summary.csv)、[results/summary.json](results/summary.json) 和 [实验说明](results/dev-comparison.md)。

## SParC 问题分类

| 问题类型 | Dev 轮数 |
|---|---:|
| 多表查询 | 437 |
| 嵌套或集合运算 | 119 |
| 指代候选 | 429 |
| 排序与截断 | 209 |
| 条件与值匹配 | 484 |
| 省略或条件修改候选 | 597 |
| 聚合分组 | 449 |

统计覆盖全部 1,203 轮，类别可以重叠。指代和省略采用规则筛选候选，SQL 结构类别按标准查询统计。这些类别描述任务难点。

## 复现实验

需要 Python 3.12、Git、本地 SParC 数据及有效的千问 API 账户。以下命令从包根目录执行。建议在虚拟环境中操作。

1. 安装依赖，下载 NLTK 分词资源。

   ```sh
   python -m pip install -r outputs/sparc_api_lab/requirements.txt
   python -m nltk.downloader -d work/sparc/nltk_data punkt punkt_tab
   ```

2. 从 [SParC 官方主页](https://yale-lily.github.io/sparc/) 下载数据，将解压后的 `sparc/` 目录放在 `work/sparc/data/` 下。确认 `work/sparc/data/sparc/dev.json`、`tables.json` 和 `database/` 存在。
3. 从 [官方 Test Suite 评估器 README](https://github.com/taoyds/test-suite-sql-eval) 下载测试数据库（压缩包约 1.3 GB）。将其中的 `database/` 放在 `work/sparc/test-suite-databases/` 下。需要保留 Dev 所用 20 个数据库目录下的全部变体。
4. 获取与实验相同的评估器版本。

   ```sh
   git clone https://github.com/taoyds/test-suite-sql-eval.git work/sparc/test-suite-sql-eval
   git -C work/sparc/test-suite-sql-eval checkout e97acc546ecbee8fa27fa8dbf025ef61493a876c
   ```

5. 复制 `outputs/sparc_api_lab/config.qwen.example.json` 为同目录的 `config.local.json`，复制 `.env.example` 为 `.env`，填写 `DASHSCOPE_API_KEY`。使用复现所需的 `qwen-plus` 配置。历史实验记录的是服务商模型别名，服务商更新可能改变输出。
6. 在一个终端启动本地后端，在另一个终端启动对照实验。

   ```sh
   python outputs/sparc_api_lab/backend.py
   ```

   ```sh
   python outputs/sparc_api_lab/lab.py preflight
   python run_dev.py --comparison single-dual --run-prefix dev_single_dual
   ```

   两组共 2,406 轮，会产生 API 费用。每组并行执行 4 段对话，单段内按轮次顺序执行。中断后可用相同前缀恢复已保存的结果。硬停机若留下 `parallel_runner.lock`，先确认该运行的进程已经退出，再移除对应的锁文件。也可以先用 `python outputs/sparc_api_lab/lab.py run --split dev --mode baseline --run-id smoke --limit 3` 验证 API。

7. 在 `outputs/sparc_api_lab/runs/dev_single_dual_comparison/` 查看汇总 CSV 和 JSON。两组运行各有预测、逐轮日志和评估记录。两组都跑完后可添加 `--score-only` 离线重评分。若要复现早期基线对照，使用 `--comparison baseline-agent` 并指定另一个运行前缀。

EM 按原始标准 SQL 使用官方评估器。Test Suite 使用相同评估器的执行逻辑，并对一个标准答案补全缺失的 T1 别名。运行时适配包括 Windows 同步 SQLite、60 秒查询超时保护以及恒等列排列快捷判断。历史两组 Dev 评分均未触发超时。Dev 指官方开发集，原论文也单列了隐藏 Test 成绩。

## 本地验证

```sh
python outputs/sparc_api_lab/test_lab.py
python work/sparc-report/test_parallel_resume.py
```

后端仅监听本机，使用本地令牌。它是本项目的实验后端。RSI 原工程与其前端资产需从各自来源取得。评估脚本面向本项目生成的预测和官方基准数据。

## 来源与发布

数据、评估器与第三方依赖各自遵循上游条款。包内包含实验实现、配置模板与汇总指标。引用数据集时请引用 Yu 等人的 ACL 2019 论文。[SParC 数据集主页](https://yale-lily.github.io/sparc/) · [论文与引用](https://aclanthology.org/P19-1443/) · [官方评估器](https://github.com/taoyds/test-suite-sql-eval)

发布者应确认持有项目代码的发布权，并为本项目选择许可证、在仓库根目录添加 `LICENSE`。此发布准备包的项目许可证待确定。
